%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-10T20:18:34+03:00*%
%TF.ProjectId,slab_A1_lin000,736c6162-5f41-4315-9f6c-696e3030302e,B (pre-EM-tuning)*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-10 20:18:34*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,7.000000*%
G04 APERTURE END LIST*
D10*
%TO.C,D1*%
X10000000Y0D03*
%TD*%
M02*
