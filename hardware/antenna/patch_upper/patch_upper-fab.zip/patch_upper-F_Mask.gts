%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-10T15:14:43+03:00*%
%TF.ProjectId,patch_upper,70617463-685f-4757-9070-65722e6b6963,A (pre-EM-tuning)*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-10 15:14:43*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,H2*%
X58000000Y0D03*
%TD*%
%TO.C,H1*%
X0Y58000000D03*
%TD*%
%TO.C,H3*%
X0Y-58000000D03*
%TD*%
%TO.C,H4*%
X-58000000Y0D03*
%TD*%
M02*
